# Endanger-Animal-Monitoring-System
php &amp; mysql
